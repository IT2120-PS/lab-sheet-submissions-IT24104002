setwd("C:\\Users\\dinu9\\Desktop\\IT24104002")

#Question 1

#(01)
#Binomial Distribution
n <- 50
p <- 0.85

#(02)
#P(X >= 47) = 1-P(x <= 46)
1 - pbinom(46, n, p, lower.tail = TRUE)
pbinom(46, n, p, lower.tail = FALSE)


#Question 2

#(01)
#Number of calls a call center recieves per hour

#(02) 
#Poisson Distribution
#Lambda = 12

#(03)
lambda <- 12
dpois(15,lambda)